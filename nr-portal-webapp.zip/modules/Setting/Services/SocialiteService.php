<?php

namespace Modules\Setting\Services;

use Modules\Setting\Repositories\SocialiteRepository;

class SocialiteService
{
    /**
     * @var $socialiteRepository
     */
    protected $socialiteRepository;

    /**
     * Constructor
     *
     * @param SocialiteRepository $socialiteRepository
     */
    public function __construct(SocialiteRepository $socialiteRepository)
    {
        $this->socialiteRepository = $socialiteRepository;
    }

    /**
     * Get all data
     *
     * @param int $limit
     * @return mixed
     */
    public function all($limit = 0)
    {
        return $this->socialiteRepository->paginate($limit);
    }

    /**
     * Get all data
     *
     * @param $data
     * @return mixed
     */
    public function create($data)
    {
        return $this->socialiteRepository->create($data);
    }

    /**
     * Find data
     *
     * @param $id
     * @return mixed
     */
    public function find($id)
    {
        return $this->socialiteRepository->find($id);
    }

    /**
     * Update data
     *
     * @param $data
     * @param $id
     * @return mixed
     */
    public function update($data, $id)
    {
        return $this->socialiteRepository->update($data, $id);
    }

    /**
     * Delete data
     *
     * @param $id
     * @return mixed
     */
    public function delete($id)
    {
        return $this->socialiteRepository->delete($id);
    }

    /**
     * First or create data
     *
     * @param $data
     * @return mixed
     */
    public function firstOrCreate($data)
    {
        return $this->socialiteRepository->model->firstOrCreate($data);
    }
}
