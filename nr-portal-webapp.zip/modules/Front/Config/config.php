<?php

return [
    'name' => 'Front'
];
